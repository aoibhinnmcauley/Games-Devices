/** Automatically generated file. DO NOT MODIFY */
package ie.itcarlow.andengine.examples;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
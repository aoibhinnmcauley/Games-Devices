package ie.itcarlow.andengine.examples;

import ie.itcarlow.andengine.examples.SceneManager.AllScenes;

import org.andengine.audio.sound.Sound;
import org.andengine.audio.sound.SoundFactory;
import org.andengine.engine.camera.Camera;
import org.andengine.engine.handler.timer.ITimerCallback;
import org.andengine.engine.handler.timer.TimerHandler;
import org.andengine.engine.options.EngineOptions;
import org.andengine.engine.options.ScreenOrientation;
import org.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.andengine.entity.scene.Scene;
import org.andengine.entity.scene.background.Background;
import org.andengine.entity.sprite.AnimatedSprite;
import org.andengine.entity.sprite.Sprite;
import org.andengine.extension.physics.box2d.PhysicsConnector;
import org.andengine.extension.physics.box2d.PhysicsFactory;
import org.andengine.extension.physics.box2d.PhysicsWorld;
import org.andengine.extension.physics.box2d.util.Vector2Pool;
import org.andengine.extension.physics.box2d.util.constants.PhysicsConstants;
import org.andengine.input.touch.TouchEvent;
import org.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlas;
import org.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlasTextureRegionFactory;
import org.andengine.opengl.texture.region.ITiledTextureRegion;
import org.andengine.ui.activity.BaseGameActivity;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.Manifold;

//import org.andengine.engine.handler.collision.CollisionHandler;
//import org.andengine.engine.handler.collision.ICollisionCallback;
//import org.andengine.engine.handler.physics.PhysicsHandler;
//import org.andengine.entity.shape.IShape;
//import org.andengine.engine.handler.collision.CollisionHandler;
//import org.andengine.engine.handler.collision.ICollisionCallback;
//import org.andengine.engine.handler.physics.PhysicsHandler;
//import org.andengine.entity.shape.IShape;
//import org.andengine.engine.handler.collision.CollisionHandler;
//import org.andengine.engine.handler.collision.ICollisionCallback;
//import org.andengine.engine.handler.physics.PhysicsHandler;
//import org.andengine.entity.shape.IShape;
//import org.andengine.engine.handler.collision.CollisionHandler;
//import org.andengine.engine.handler.collision.ICollisionCallback;
//import org.andengine.engine.handler.physics.PhysicsHandler;
//import org.andengine.entity.shape.IShape;
//import org.andengine.engine.handler.collision.CollisionHandler;
//import org.andengine.engine.handler.collision.ICollisionCallback;
//import org.andengine.engine.handler.physics.PhysicsHandler;
//import org.andengine.entity.shape.IShape;
//import org.andengine.engine.handler.collision.CollisionHandler;
//import org.andengine.engine.handler.collision.ICollisionCallback;
//import org.andengine.engine.handler.physics.PhysicsHandler;
//import org.andengine.entity.shape.IShape;
//import org.andengine.engine.handler.collision.CollisionHandler;
//import org.andengine.engine.handler.collision.ICollisionCallback;
//import org.andengine.engine.handler.physics.PhysicsHandler;
//import org.andengine.entity.shape.IShape;
//import org.andengine.engine.handler.collision.CollisionHandler;
//import org.andengine.engine.handler.collision.ICollisionCallback;
//import org.andengine.engine.handler.physics.PhysicsHandler;
//import org.andengine.entity.shape.IShape;

public class AndengineMinimalExampleActivity extends BaseGameActivity {
	// ===========================================================
	// Constants
	// ===========================================================
	private static final int CAMERA_WIDTH = 500;
	private static final int CAMERA_HEIGHT = 500;
	//private PhysicsHandler mPhysicsHandler;
	// ===========================================================
	// Fields
	// ===========================================================
	
	private Scene mScene;
	

	private SceneManager mSceneManager;
	private Camera mCamera;
	//boolean colliding = false; 
	//MediaPlayer sound = MediaPlayer.create(this, .raw.sound.wav);
	@Override
	public EngineOptions onCreateEngineOptions() {
    mCamera = new Camera(0, 0, CAMERA_WIDTH,CAMERA_HEIGHT);
	final EngineOptions engineOptions = new EngineOptions(true, ScreenOrientation.LANDSCAPE_FIXED, new RatioResolutionPolicy(CAMERA_WIDTH, CAMERA_HEIGHT), mCamera);
    engineOptions.getAudioOptions().setNeedsSound(true);
      return engineOptions;
	}
	
	@Override
	public void onCreateResources(
	OnCreateResourcesCallback pOnCreateResourcesCallback)
	throws Exception {
		mSceneManager = new SceneManager(this, mEngine, mCamera);
		mSceneManager.loadSplashResources();	
	loadGfx(); 
	  SoundFactory.setAssetBasePath("sfx/");
	     
    
	pOnCreateResourcesCallback.onCreateResourcesFinished();
	
	}
	private void loadGfx() {
	BitmapTextureAtlasTextureRegionFactory.setAssetBasePath("gfx/");
	// width and height power of 2^x
	

	}

	
	@Override
	public void onCreateScene(OnCreateSceneCallback
	pOnCreateSceneCallback)
	throws Exception {
	this.mScene = new Scene();
	this.mScene.setBackground(new Background(0, 125, 58));
	
    // mSound = SoundFactory.createSoundFromAsset(getSoundManager(), this, "sound.wav");
	//pOnCreateSceneCallback.onCreateSceneFinished(this.mScene);
	pOnCreateSceneCallback.onCreateSceneFinished(mSceneManager.createSplashScene());
	
	}

	
	
	@Override
	public void onPopulateScene(Scene pScene,
	OnPopulateSceneCallback pOnPopulateSceneCallback)
	throws Exception {
	// Setup coordinates for the face, so its centered on the camera.
		mEngine.registerUpdateHandler(new TimerHandler(3f,
				new ITimerCallback() {
					@Override
					public void onTimePassed(TimerHandler pTimerHandler) {
						mEngine.unregisterUpdateHandler(pTimerHandler);
					//	 TODO Auto-generated method stub
				mSceneManager.loadMenuResources();
						mSceneManager.loadGameResources();
						mSceneManager.createMenuScene();
						mSceneManager.setCurrentScene(AllScenes.MENU);
					}
				}));
		pOnPopulateSceneCallback.onPopulateSceneFinished();
		
}
	
	
	
  }

	
	    
	 
	
	
	
	            

	



